import React from 'react'
import './style.css'
import Calci from "./calci"



function App() {
    return ( 
        < Calci/>
    )
}
export default App;