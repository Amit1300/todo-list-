import React from 'react'

//  import  Children from './children'
// import './style.css'
// // import Calci from "./calci"
//  import Details from "./details"


import Todolist from './component/todolist'


function App() {
    return ( 
        // < Calci/>
        <div>
        <Todolist/>

        {/* <Details>
        <Children />
        </Details> */}

        </div>
        
       
    )
}
export default App;